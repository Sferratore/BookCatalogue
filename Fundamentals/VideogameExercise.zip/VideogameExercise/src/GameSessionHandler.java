import java.util.Scanner;

public class GameSessionHandler {

	//-------------CONSTRUCTORS---------------------
	public GameSessionHandler() {
		this.userHandler = new UserMemory();
		this.inputScanner = new Scanner(System.in);
		this.isAnyUserLogged = false;
	}
	
	//-------------METHODS--------------------------
	
	public boolean register() {
		
		try {
			this.userLogged = new User();
			
			System.out.println("Your username: ");
			this.userLogged.setUsername(inputScanner.next());
			
			System.out.println("Your password: ");
			this.userLogged.setUsername(inputScanner.next());
			
			this.userLogged.setAdmin(false);
			
			this.userHandler.registerUser(userLogged);
			this.isAnyUserLogged = true;
			
			return true;
		}
		catch(Exception e) {
			System.out.println("SOMETHING WENT WRONG WITH THE OPERATION." + e.toString());
			System.exit(0);
			return false;
		}
				
	}
	
	public boolean logIn() {
		
		try {
			this.userLogged = new User();
			
			System.out.println("Your username: ");
			this.userLogged.setUsername(inputScanner.next());
			
			System.out.println("Your password: ");
			this.userLogged.setUsername(inputScanner.next());
			
			this.userLogged.setAdmin(false);
			
			if(this.userHandler.logUserIn(userLogged)) {
				this.isAnyUserLogged = true;
				System.out.println("Logged in successfully.");
				return true;
			}
			else {
				this.userLogged = null;
				System.out.println("Login failed.");
			}
		}
		catch(Exception e) {
			System.out.println("SOMETHING WENT WRONG WITH THE OPERATION." + e.toString());
			
		}
		return false;
	}
	
	
	//-------------FIELDS---------------------------
	private UserMemory userHandler;
	private User userLogged;
	private boolean isAnyUserLogged;
	private Scanner inputScanner;
	
}
