
public class Main {

	public static void main(String[] args) {

		Videogame[] videogameArray = new Videogame[5];
		
		videogameArray[0] = new Videogame("Donkey Kong", "Platform");
		videogameArray[1] = new ActionVideogame("Super smash bros.");
		videogameArray[2] = new StrategyVideogame("Fire Emblem");
		videogameArray[3] = new Videogame("Super Mario 64", "Platform");
		videogameArray[4] = new Videogame("The Legend of Zelda: Oracle of Seasons", "RPG");
		
		for(int i = 0; i < 5; i++) {
			System.out.println(videogameArray[i]);
		}
		
	}

}
